


local xPos = 120
local yPos = 100
local flipH = false

--player information
p1=
{
	--position, representing the top left of
	--of the player sprite.
	x=120,
	y=100,
	dx=0,
	dy=0,

	--is the player standing on
	--the ground. used to determine
	--if they can jump.
	isgrounded=false,

	--how fast the player is launched
	--into the air when jumping.
	jumpvel=3.0,
}

g=
{
	grav=0.1, -- gravity per frame
}

--[[
  The Init() method is part of the game's lifecycle and called a game starts.
  We are going to use this method to configure background color,
  ScreenBufferChip and draw a text box.
]]--
function Init()

  -- Here we are manually changing the background color
  BackgroundColor(1)

  local display = Display()

  PlaySong(0, false, 0)

end

--[[
  The Update() method is part of the game's life cycle. The engine calls
  Update() on every frame before the Draw() method. It accepts one argument,
  timeDelta, which is the difference in milliseconds since the last frame.
]]--
function Update(timeDelta)

  --remember where we started
	local startx=p1.x

	--bleed off our horizontal speed from the last frame
  p1.dx *= 0.9


  --jumping
  if(Button(Buttons.A, InputState.Released, 0)) then
    if p1.isgrounded then
      PlaySound(4, 1 )
      p1.dy=-p1.jumpvel
    end
  end

	--left and right. We flip the sprite if going left
   if(Button(Buttons.left, InputState.Down, 0)) then
     p1.dx=-1
     flipH = true
   end
   if(Button(Buttons.right, InputState.Down, 0)) then
     p1.dx=1
     flipH = false
   end


   --apply the horizontal acceleration
   p1.x=p1.x+p1.dx

   local xoffset=0 --moving left check the left side of sprite.
 	 if p1.dx>0 then xoffset=7 end --moving right, check the right side.

  --look for a wall on either the left or right of the player
 	--and at the players feet.
 	--We divide by 8 to put the location in TileMap space (rather than
 	--pixel space).
	--The flag method basically gives us the flag ID of the corresponding position
	-- in the tilemap.
 	local flag=Flag((p1.x+xoffset)/8,(p1.y+7)/8)
 	--We use flag 0  to represent solid walls. This is set in the tilemap tool
 	if flag==0 then
 		--they hit a wall so move them
 		--back to their original pos.
 		--it should really move them to
 		--the edge of the wall but this
 		--mostly works and is simpler.
 		p1.x=startx
 	end


   --accumulate gravity
   p1.dy=p1.dy+g.grav

   --apply gravity to the players position.
   p1.y=p1.y+p1.dy

   --assume they are floating
   --until we determine otherwise
   p1.isgrounded=false

   --only check for floors when
 	--moving downward
 	if p1.dy>=0 then
 		--check bottom center of the
 		--player.

 		local flag=Flag((p1.x+4)/8,(p1.y+8)/8)

  	--look for a solid tile
 		if flag==0 then
 			--place p1 on top of tile
 			p1.y = math.floor((p1.y)/8)*8
 			--halt velocity
 			p1.dy = 0
 			--allow jumping again
 			p1.isgrounded=true
 		end
 	end



	--only check for ceilings when
	--moving up
	if p1.dy<=0 then
		--check top center of player
		local flag=Flag((p1.x+4)/8,(p1.y)/8)
		--look for solid tile
		if flag==0 then
			--position p1 right below
			--ceiling
			p1.y = math.floor((p1.y+8)/8)*8
			--halt upward velocity
			p1.dy = 0
		end
	end




end

--[[
  The Draw() method is part of the game's life cycle. It is called after
  Update() and is where all of our draw calls should go. We'll be using this
  to render sprites to the display.
]]--
function Draw()

  Clear()


  DrawSprite(0, p1.x, p1.y, flipH, false, DrawMode.Sprite)

 --draws the whole visible tilemap. 
 	DrawTilemap()

  DrawText("MS GUTS Challenge!", 50,4,DrawMode.Sprite,"small", 14)
	DrawText("X to jump", 90,30,DrawMode.Sprite,"small", 14)
	DrawText("arrows to move", 70,70,DrawMode.Sprite,"small", 14)



end
